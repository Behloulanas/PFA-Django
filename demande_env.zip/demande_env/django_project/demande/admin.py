from django.contrib import admin

from .models import Demande

admin.site.register(Demande)